/* 
 * File:   wiegand.h
 * Author: gilson
 *
 * Created on 17 de Mar�o de 2017, 08:38
 */

#ifndef WIEGAND_H
#define	WIEGAND_H

void enviaWiegand(unsigned char *data, int tamanho);

#ifdef	__cplusplus
extern "C" {
#endif



    

#ifdef	__cplusplus
}
#endif

#endif	/* WIEGAND_H */


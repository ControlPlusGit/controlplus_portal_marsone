/* 
 * File:   gps.h
 * Author: none
 *
 * Created on 27 de Fevereiro de 2015, 14:39
 */

#ifndef GPS_H
#define	GPS_H

#ifdef	__cplusplus
extern "C" {
#endif

void ProcessaGPS(void); //Apenas para testes
void ProcessaNaInterrupcaoDeUart(char dado);

void iniciaGPS (void);

#define TAMANHO_MAXIMO_STRING_VALIDADE_GPS 5
#define TAMANHO_MAXIMO_STRING_DATA_E_HORA_GPS 10
#define TAMANHO_MAXIMO_STRING_LATITUDE_E_LONGITUDE_GPS 50


extern char StringResultadoValidadeGPS[TAMANHO_MAXIMO_STRING_VALIDADE_GPS];
extern char stringResultadoLatitudeGPS[TAMANHO_MAXIMO_STRING_LATITUDE_E_LONGITUDE_GPS];
extern char stringResultadoLongitudeGPS[TAMANHO_MAXIMO_STRING_LATITUDE_E_LONGITUDE_GPS];




#ifdef	__cplusplus
}
#endif

#endif	/* GPS_H */


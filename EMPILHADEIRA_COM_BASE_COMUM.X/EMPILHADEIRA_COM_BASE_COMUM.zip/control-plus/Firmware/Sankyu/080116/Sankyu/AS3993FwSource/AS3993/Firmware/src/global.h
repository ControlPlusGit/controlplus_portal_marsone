/*
 *****************************************************************************
 * Copyright by ams AG                                                       *
 * All rights are reserved.                                                  *
 *                                                                           *
 * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
 * THE SOFTWARE.                                                             *
 *                                                                           *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
 *****************************************************************************
 */
/** @file
  * @brief This file provides declarations for global helper functions.
  *
  * @author Ulrich Herrmann
  */
#define AMBEV
#define SANKYU 1
#define EMPILHADEIRA
//#define ESTOQUE_EM_JOAO_MONLEVAD
//#define BARBACENA 1
//#define RAIZEN_RETRO
//#define PORTAL_AMBEV
//#define TECBAN 1
//#define PLACA_TECBAN 1
//#define DEMO 1
//#define ANATEL
//#define AJUSTA_ANTENA
//#define BUSCA_TAG
//#define RF_NOVA
//#define VARAL
#define ANTENA_ATUAL 1
#define CPU715

//#define VIVO 1
//#define CLARO 1
//#define TIM 1
#define OI 1

//1 a 10 portal
//11 e acima empilhadeira
//#define DUAS_ANTENAS_AMBEV
#define DISPLAY
#ifdef AMBEV            //*846# para saber no. TIM
#define NUM_SERIE 5
//982027303=11=USP3(3984), 954223796=12=4024, 986803131=23=
#elif PORTAL_AMBEV      //954286235=14=3669 , 984805367=15=2450,987492807=16=3576
#define NUM_SERIE 10    //957920551=13=4025
#else
#define NUM_SERIE 1
#endif
//Sankyu:728D=11,729D=12,730D=13,731D=14,732D=15,733D=16,734D=17,735D=18,736D=19,737D=20,738D=25
//740D=22,741D=23

#ifndef __GLOBAL_H__
#define __GLOBAL_H__

/** Defines uC used clock frequency */
#define SYSCLK_16MHZ                16000000ULL
#define SYSCLK_12MHZ                12000000ULL
#define SYSCLK_8MHZ                 8000000ULL
#define SYSCLK_4MHZ                 4000000ULL
#if 1
#define SYSCLK    SYSCLK_16MHZ
#else
#define SYSCLK    tbd
#endif
#define FCY    (SYSCLK)

#include "as3993_config.h"
#include "ams_types.h"

/** Definition high */
#define HIGH                      1

/** Definition all bits low */
#define LOW                       0

#define BIT0	0x01
#define BIT1	0x02
#define BIT2	0x04
#define BIT3	0x08
#define BIT4	0x10
#define BIT5	0x20
#define BIT6	0x40
#define BIT7	0x80

void bin2Chars(int value, unsigned char *destbuf);
void bin2Hex(char value, unsigned char *destbuf);
void u32ToEbv(u32 value, u8 *ebv, u8 *len);
void insertBitStream(u8 *dest, u8 const *source, u8 len, u8 bitpos);
u32 readU32FromLittleEndianBuffer(u8 const *buffer);
void recebeOperador (u8 dado);
//void resetContadores (void);
void bloqueia_frente(void);
void bloqueia_reh(void);
void ld_saidas(int saida, int status);
void sel_led(int led, int status);
//void escolhe_antena(void);

extern volatile int operador_atual_outro;


/** Definition for the maximal EPC length */
#define EPCLENGTH              12 //32  // number of bytes for EPC, standard allows up to 62 bytes
/** Definition for the PC length */
#define PCLENGTH                2
/** Definition for the CRC length */
#define CRCLENGTH               2
/** Definition of the maximum frequencies for the hopping */
#define MAXFREQ                 53
/** Definition of the maximum tune entries in tuning table */
#define MAXTUNE                 52
/** Definition of the maximum number of tags, which can be read in 1 round */
//#define MAXTAG 255
#define MAXTAG 12//20//120

#endif

#ifndef FIFO_H
#define FIFO_H

#define TAMANHO_MAXIMO_DA_TABELA 20
#define TAMANHO_MAXIMO_DO_ITEM 10


int adicionaElementoAFifo(char *Item);
int retornaComItemDaLista(char *Item);
int removePrimeiroItem(void);


#endif
